@echo off
chcp 65001 >nul

:: バッチファイルがあるフォルダに移動する
cd /d "%~dp0"

:: 管理者権限で実行されているかチェック＆昇格
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo 管理者権限で再起動します...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: 念のため開いているマウスのプロパティを閉じる
taskkill /f /im rundll32.exe >nul 2>&1

:: 1. フォルダの作成
set "SchemeName=動く！正弦波くんとPCカーソル"
set "TargetDir=C:\Windows\Cursors\%SchemeName%"

if not exist "%TargetDir%" (
    mkdir "%TargetDir%"
)

:: 2. カーソルファイルをWindowsのCursorsフォルダにコピー
copy /y "*.ani" "%TargetDir%\" >nul
copy /y "*.cur" "%TargetDir%\" >nul

:: 3. レジストリへの一括登録 ＆ 即時リフレッシュ命令
powershell -Command "$s='動く！正弦波くんとPCカーソル'; $p='HKCU:\Control Panel\Cursors'; Set-ItemProperty -Path $p -Name '(Default)' -Value $s; Set-ItemProperty -Path $p -Name 'Arrow' -Value \"C:\Windows\Cursors\$s\通常.ani\"; Set-ItemProperty -Path $p -Name 'Help' -Value \"C:\Windows\Cursors\$s\ヘルプ.ani\"; Set-ItemProperty -Path $p -Name 'AppStarting' -Value \"C:\Windows\Cursors\$s\領域.ani\"; Set-ItemProperty -Path $p -Name 'Wait' -Value \"C:\Windows\Cursors\$s\ロード.ani\"; Set-ItemProperty -Path $p -Name 'Crosshair' -Value \"C:\Windows\Cursors\$s\移動.cur\"; Set-ItemProperty -Path $p -Name 'IBeam' -Value \"C:\Windows\Cursors\$s\テキスト.ani\"; Set-ItemProperty -Path $p -Name 'NWPen' -Value \"C:\Windows\Cursors\$s\手書き.ani\"; Set-ItemProperty -Path $p -Name 'No' -Value \"C:\Windows\Cursors\$s\不可.cur\"; Set-ItemProperty -Path $p -Name 'SizeNS' -Value \"C:\Windows\Cursors\$s\上下.cur\"; Set-ItemProperty -Path $p -Name 'SizeWE' -Value \"C:\Windows\Cursors\$s\左右.cur\"; Set-ItemProperty -Path $p -Name 'SizeNWSE' -Value \"C:\Windows\Cursors\$s\斜め1.cur\"; Set-ItemProperty -Path $p -Name 'SizeNESW' -Value \"C:\Windows\Cursors\$s\斜め2.cur\"; Set-ItemProperty -Path $p -Name 'SizeAll' -Value \"C:\Windows\Cursors\$s\移動.cur\"; Set-ItemProperty -Path $p -Name 'UpArrow' -Value \"C:\Windows\Cursors\$s\代替.cur\"; Set-ItemProperty -Path $p -Name 'Hand' -Value \"C:\Windows\Cursors\$s\リンク.ani\"; $Signature = '[DllImport(\"user32.dll\")] public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, IntPtr pvParam, uint fWinIni);'; $Type = Add-Type -MemberDefinition $Signature -Name 'Win32Cursors' -Namespace 'Win32Functions' -PassThru; [Win32Functions.Win32Cursors]::SystemParametersInfo(0x0057, 0, [IntPtr]::Zero, 0x02)"

echo.
echo ==========================================
echo カーソルの変更が完了しました！
echo ==========================================
pause